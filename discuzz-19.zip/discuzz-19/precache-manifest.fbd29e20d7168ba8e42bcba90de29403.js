self.__precacheManifest = [
  {
    "revision": "606b8e96894f15596c83333e923a3a62",
    "url": "editor/dialogs/video/images/file-icons.gif"
  },
  {
    "revision": "cc114c6d12a97635096956aab117b4d4",
    "url": "editor/third-party/zeroclipboard/ZeroClipboard.swf"
  },
  {
    "revision": "ac9353bebe7c6878036d0359a0ff9974",
    "url": "editor/ueditor.parse.min.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "cc550f64016dfb933e28937c254502ab",
    "url": "editor/ueditor.parse.js"
  },
  {
    "revision": "7b9e9c591a4a3ad45fa807ffee857aff",
    "url": "editor/ueditor.all.min.js"
  },
  {
    "revision": "a18e7aef147b39a757ea88195e981f97",
    "url": "editor/ueditor.all.js"
  },
  {
    "revision": "bb69a999e69b289688c1fcd86a5c2a61",
    "url": "editor/ueditor.config.js"
  },
  {
    "revision": "a07798cdd17d460a46b18a22c5ee9b8d",
    "url": "index.html"
  },
  {
    "revision": "17e1af76de01403df026af28cc4aecda",
    "url": "editor/dialogs/video/images/right_focus.jpg"
  },
  {
    "revision": "64ce67cb62cc89f4fa70",
    "url": "assets/js/chunk-1e5be3a0.c507cb12.js"
  },
  {
    "revision": "527c3d756b0d22aeb122dc5d8da33e17",
    "url": "editor/third-party/webuploader/webuploader.flashonly.min.js"
  },
  {
    "revision": "841660f6648f9d2496a2",
    "url": "assets/js/chunk-382e845f.b8de99d6.js"
  },
  {
    "revision": "abc302b1f8a85cf5dd9d",
    "url": "assets/js/chunk-670df707.87cf4d6c.js"
  },
  {
    "revision": "cd022aa32cf4146a2d405bdade9a7316",
    "url": "editor/third-party/zeroclipboard/ZeroClipboard.min.js"
  },
  {
    "revision": "f20d0941387f7e771cde",
    "url": "assets/js/chunk-881417c4.12a047a7.js"
  },
  {
    "revision": "e11d9bc7dee10f72092a0867203251e8",
    "url": "editor/third-party/webuploader/webuploader.html5only.min.js"
  },
  {
    "revision": "0d60c84ad452d3c0fe02",
    "url": "assets/js/chunk-b2e0cb02.a8c3c716.js"
  },
  {
    "revision": "56acbc88efd2b5c82448f8db32f1efa9",
    "url": "editor/third-party/zeroclipboard/ZeroClipboard.js"
  },
  {
    "revision": "54afb1a43f1fad9b6d44",
    "url": "assets/js/chunk-vendors.1cbbd04c.js"
  },
  {
    "revision": "033a89d00bfc5aef6d9bc9c998cffb53",
    "url": "editor/third-party/xss.min.js"
  },
  {
    "revision": "3c3e8c363933509550c4a3709d514ee1",
    "url": "editor/third-party/webuploader/webuploader.withoutimage.min.js"
  },
  {
    "revision": "ac30cd2e245e5988d8cfb2dc6f185ec2",
    "url": "editor/third-party/webuploader/webuploader.withoutimage.js"
  },
  {
    "revision": "43487dfd7e2db6a93302608a16bb9424",
    "url": "editor/third-party/webuploader/webuploader.min.js"
  },
  {
    "revision": "6c75aae8048de3d23cee4b255278a437",
    "url": "editor/third-party/webuploader/webuploader.js"
  },
  {
    "revision": "c4a3bf9b5186325ae81a0c459f14798a",
    "url": "editor/third-party/webuploader/webuploader.flashonly.js"
  },
  {
    "revision": "2cdc7bb54db94e5c8f842da451b46e93",
    "url": "editor/third-party/webuploader/webuploader.html5only.js"
  },
  {
    "revision": "ee305c10a48030b2cb303c29e1a6c8a2",
    "url": "editor/third-party/webuploader/webuploader.custom.js"
  },
  {
    "revision": "9bffc8ad91cf0e7e84dbb3e5f1eea23d",
    "url": "editor/third-party/video-js/video.js"
  },
  {
    "revision": "5fd18b38672ad1342eccf241abead795",
    "url": "editor/third-party/webuploader/webuploader.custom.min.js"
  },
  {
    "revision": "501a397c5bac2b02206a4fc855875136",
    "url": "editor/third-party/webuploader/Uploader.swf"
  },
  {
    "revision": "6979b2e79474bd0a8b84edce64b89ae1",
    "url": "editor/third-party/video-js/video-js.css"
  },
  {
    "revision": "ca70e29d4161ce4494199f2d088e98ca",
    "url": "editor/third-party/webuploader/webuploader.css"
  },
  {
    "revision": "18c42d25190ad7ed229436868ffe0a4f",
    "url": "editor/third-party/video-js/video.dev.js"
  },
  {
    "revision": "702310fa9455af3bc20ff48129d5c6ef",
    "url": "editor/dialogs/attachment/attachment.html"
  },
  {
    "revision": "f76251acf9a314912f04f1623b902ffd",
    "url": "editor/dialogs/anchor/anchor.html"
  },
  {
    "revision": "a6bde967007a598c248c28e93135f8d2",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_chm.gif"
  },
  {
    "revision": "2c861195d4fe149d298fb89f59fb59db",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_default.png"
  },
  {
    "revision": "62fedaf25e736ec0fc5dc9f484f8729f",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_doc.gif"
  },
  {
    "revision": "18637ff2025925f1c8efcafcffc341a6",
    "url": "editor/dialogs/attachment/attachment.css"
  },
  {
    "revision": "206ee8fa1eb6472dbf6680d1a234730e",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_jpg.gif"
  },
  {
    "revision": "20ca745781a4181242486fd6899b311e",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_mp3.gif"
  },
  {
    "revision": "2a223aacd85e50241e09ee50208444cc",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_exe.gif"
  },
  {
    "revision": "5ed2e815d975ef2f28415808c97aa825",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_pdf.gif"
  },
  {
    "revision": "8ca7522b42fd080284556579c9429fcb",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_ppt.gif"
  },
  {
    "revision": "b89eb6e0820bca6cb13cc0471f9c6408",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_mv.gif"
  },
  {
    "revision": "ec5c6a20543d04ed58473ddc0017aa06",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_rar.gif"
  },
  {
    "revision": "569ce65a6f5ef037358a8720d32acce5",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_psd.gif"
  },
  {
    "revision": "a41b31caae5723d931c6365ae180c0be",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_txt.gif"
  },
  {
    "revision": "bf802fe93791f4d760c29ac3fbc780da",
    "url": "editor/dialogs/attachment/attachment.js"
  },
  {
    "revision": "43750beef8caa96f0e1ef476539f65f4",
    "url": "editor/dialogs/attachment/fileTypeImages/icon_xls.gif"
  },
  {
    "revision": "dc9038bc535e0f930306894cf24ccd4c",
    "url": "editor/dialogs/attachment/images/icons.gif"
  },
  {
    "revision": "ceea3f7e3d18fbefe125725c85a57aeb",
    "url": "editor/dialogs/attachment/images/bg.png"
  },
  {
    "revision": "aef70d0a71f4b1da729a92dafd4cf4a9",
    "url": "editor/dialogs/attachment/images/alignicon.png"
  },
  {
    "revision": "d86d56edfe175c9aa300a8ef4c7f78c6",
    "url": "editor/dialogs/attachment/images/alignicon.gif"
  },
  {
    "revision": "6b00566e6a7a54df0b83fe8a1d8b9427",
    "url": "editor/dialogs/attachment/images/image.png"
  },
  {
    "revision": "c9ceb83c0a247ae47f54c3e1d3cb4bac",
    "url": "editor/dialogs/attachment/images/icons.png"
  },
  {
    "revision": "56879ca275183bef11a8972ffbea5a6b",
    "url": "editor/dialogs/attachment/images/success.gif"
  },
  {
    "revision": "46732e763f50c337fecabcc42150d842",
    "url": "editor/dialogs/attachment/images/progress.png"
  },
  {
    "revision": "b80425bbf53402d499d54c86ca365870",
    "url": "editor/dialogs/attachment/images/success.png"
  },
  {
    "revision": "536bc185c6b5dfcf1e8810c562389265",
    "url": "editor/dialogs/background/background.css"
  },
  {
    "revision": "04a7705279b7577e38e4c671a2f998ea",
    "url": "editor/dialogs/background/background.html"
  },
  {
    "revision": "4357eaff4d2f1cbc3af001a55601bbbf",
    "url": "editor/dialogs/background/background.js"
  },
  {
    "revision": "ceea3f7e3d18fbefe125725c85a57aeb",
    "url": "editor/dialogs/background/images/bg.png"
  },
  {
    "revision": "b80425bbf53402d499d54c86ca365870",
    "url": "editor/dialogs/background/images/success.png"
  },
  {
    "revision": "f5e0dcdab3797838440b7f2f1309924e",
    "url": "editor/dialogs/charts/chart.config.js"
  },
  {
    "revision": "606b8e96894f15596c83333e923a3a62",
    "url": "editor/dialogs/attachment/images/file-icons.gif"
  },
  {
    "revision": "f43725a2e01286fd452243252df94999",
    "url": "editor/dialogs/attachment/images/file-icons.png"
  },
  {
    "revision": "b5f91ee526e77e69974806211f959c4a",
    "url": "editor/dialogs/charts/charts.css"
  },
  {
    "revision": "3b4e81fee16532bfd41960ed2b59f658",
    "url": "editor/dialogs/charts/charts.html"
  },
  {
    "revision": "250cab3fce4c33a85c6705128148aa10",
    "url": "editor/dialogs/charts/charts.js"
  },
  {
    "revision": "c8c9cdb63b5c31aaa9d075e3d12d6772",
    "url": "editor/dialogs/charts/images/charts0.png"
  },
  {
    "revision": "2042995205190212415b560e3a28ebad",
    "url": "editor/dialogs/charts/images/charts2.png"
  },
  {
    "revision": "4bebe6b730fe928031ee4f83594b300a",
    "url": "editor/dialogs/charts/images/charts1.png"
  },
  {
    "revision": "fc1c24b56a589dcd17a6721c5d576f5b",
    "url": "editor/dialogs/charts/images/charts3.png"
  },
  {
    "revision": "c509b2a9eb6a8de979dc6b4535ba3831",
    "url": "editor/dialogs/emotion/emotion.css"
  },
  {
    "revision": "3e6bd6cad01273ba4b6257a3d9437c85",
    "url": "editor/dialogs/emotion/emotion.html"
  },
  {
    "revision": "629ccc774aed95b2c6bec91151f7292d",
    "url": "editor/dialogs/emotion/images/0.gif"
  },
  {
    "revision": "eba67e20a9486696edc111ed49405d0e",
    "url": "editor/dialogs/emotion/emotion.js"
  },
  {
    "revision": "9d215c9480ab1ec3660513ad82a048b2",
    "url": "editor/dialogs/charts/images/charts5.png"
  },
  {
    "revision": "43b400c4c8fbd5458d072fe177e633fd",
    "url": "editor/dialogs/charts/images/charts4.png"
  },
  {
    "revision": "5d39be760e912b058a42fc59b3731bec",
    "url": "editor/dialogs/emotion/images/cface.gif"
  },
  {
    "revision": "4869b022d6ba52d8c4312e9f40564efd",
    "url": "editor/dialogs/emotion/images/neweditor-tab-bg.png"
  },
  {
    "revision": "a4fc234a5ca005ba8845b36a09004738",
    "url": "editor/dialogs/emotion/images/fface.gif"
  },
  {
    "revision": "30e42f9792a388ea7b049ee8715ce8fa",
    "url": "editor/dialogs/emotion/images/tface.gif"
  },
  {
    "revision": "6ea3533c3b0adbe19467ebccd1a7afa1",
    "url": "editor/dialogs/emotion/images/bface.gif"
  },
  {
    "revision": "647a02b861c53e54d603db363aeec236",
    "url": "editor/dialogs/emotion/images/wface.gif"
  },
  {
    "revision": "654ba04eecca9363d689db9c67bac1bf",
    "url": "editor/dialogs/help/help.css"
  },
  {
    "revision": "1085988d048e25ad630451eba57dc09d",
    "url": "editor/dialogs/emotion/images/jxface2.gif"
  },
  {
    "revision": "43c43aada4dd1ec8bc352f092e39c7b0",
    "url": "editor/dialogs/emotion/images/yface.gif"
  },
  {
    "revision": "bdabd1bb2e82c4114fb940de466a1d8c",
    "url": "editor/dialogs/help/help.html"
  },
  {
    "revision": "46ab3200f2cee7a9be91c7ba91dc8863",
    "url": "editor/dialogs/help/help.js"
  },
  {
    "revision": "1e48d4c9c191394d592c23c8bb3efdcc",
    "url": "editor/dialogs/gmap/gmap.html"
  },
  {
    "revision": "467dd4ead530984863d9996411124a9b",
    "url": "editor/dialogs/image/image.css"
  },
  {
    "revision": "62599344cbf8c060562d25d2cb774db0",
    "url": "editor/dialogs/image/image.html"
  },
  {
    "revision": "dc9038bc535e0f930306894cf24ccd4c",
    "url": "editor/dialogs/image/images/icons.gif"
  },
  {
    "revision": "0bffaa2001fb64832c4b07f61c28067c",
    "url": "editor/dialogs/image/images/alignicon.jpg"
  },
  {
    "revision": "c9ceb83c0a247ae47f54c3e1d3cb4bac",
    "url": "editor/dialogs/image/images/icons.png"
  },
  {
    "revision": "6b00566e6a7a54df0b83fe8a1d8b9427",
    "url": "editor/dialogs/image/images/image.png"
  },
  {
    "revision": "56879ca275183bef11a8972ffbea5a6b",
    "url": "editor/dialogs/image/images/success.gif"
  },
  {
    "revision": "45b42ca4bffcb5fcef5759485dc4d966",
    "url": "editor/dialogs/image/image.js"
  },
  {
    "revision": "ceea3f7e3d18fbefe125725c85a57aeb",
    "url": "editor/dialogs/image/images/bg.png"
  },
  {
    "revision": "46732e763f50c337fecabcc42150d842",
    "url": "editor/dialogs/image/images/progress.png"
  },
  {
    "revision": "c13309902398eafe429866bd50842ba1",
    "url": "editor/dialogs/insertframe/insertframe.html"
  },
  {
    "revision": "3bae37462fda1118d6b67df4f0b7bf7f",
    "url": "editor/dialogs/map/map.html"
  },
  {
    "revision": "c0f9b684495ee74765c2b0959b71d9aa",
    "url": "editor/dialogs/internal.js"
  },
  {
    "revision": "a6515e6b9aaf4741a39d4b522c9615cb",
    "url": "editor/dialogs/link/link.html"
  },
  {
    "revision": "0459af5c58f978d41fc485acfa47f58a",
    "url": "editor/dialogs/music/music.html"
  },
  {
    "revision": "ae6a7aeacabad9274f647078d54f78b9",
    "url": "editor/dialogs/music/music.css"
  },
  {
    "revision": "b80425bbf53402d499d54c86ca365870",
    "url": "editor/dialogs/image/images/success.png"
  },
  {
    "revision": "64d268d5749c701a9ef3af91efba1b88",
    "url": "editor/dialogs/scrawl/images/addimg.png"
  },
  {
    "revision": "f76286aaa7fbdc6046c3802d57a2a86a",
    "url": "editor/dialogs/scrawl/images/brush.png"
  },
  {
    "revision": "2091e959cbafd08fb1eed9131b9fd44c",
    "url": "editor/dialogs/scrawl/images/delimg.png"
  },
  {
    "revision": "37ebb732ae836025a8fb73a633a7a899",
    "url": "editor/dialogs/scrawl/images/empty.png"
  },
  {
    "revision": "54a5447ca3c56b999ab26a0705b4cdee",
    "url": "editor/dialogs/scrawl/images/delimgH.png"
  },
  {
    "revision": "b05b8330ec204731c28191de7c30193c",
    "url": "editor/dialogs/scrawl/images/emptyH.png"
  },
  {
    "revision": "0fc02024cda940174c098b871bf84c7c",
    "url": "editor/dialogs/map/show.html"
  },
  {
    "revision": "f7c8eda36e253d931ed9396450690d70",
    "url": "editor/dialogs/scrawl/images/redo.png"
  },
  {
    "revision": "20190473ae3f1ef61695f94f5c2b6789",
    "url": "editor/dialogs/scrawl/images/redoH.png"
  },
  {
    "revision": "04cacdc1426b6158dfe537f959e0acf2",
    "url": "editor/dialogs/scrawl/images/scale.png"
  },
  {
    "revision": "eb607e13d69ed5d13f5b3b8923f85886",
    "url": "editor/dialogs/preview/preview.html"
  },
  {
    "revision": "be0eea27c8907255c8d241187f34e440",
    "url": "editor/dialogs/scrawl/images/scaleH.png"
  },
  {
    "revision": "ed6b7fb70d0c207bebd94ad2c5f14630",
    "url": "editor/dialogs/scrawl/images/undo.png"
  },
  {
    "revision": "01014410b794e57dcb8b6163859083c7",
    "url": "editor/dialogs/scrawl/images/undoH.png"
  },
  {
    "revision": "a8b398c1e236d600088cb0178556af1a",
    "url": "editor/dialogs/scrawl/scrawl.css"
  },
  {
    "revision": "0b8509263ad87c33cee01dce5a6eaf13",
    "url": "editor/dialogs/scrawl/images/size.png"
  },
  {
    "revision": "45c7ed8b6dfdab35ffdafcbf7fc996b2",
    "url": "editor/dialogs/scrawl/scrawl.html"
  },
  {
    "revision": "71b802cd1809f338e68fc9fe64ed5108",
    "url": "editor/dialogs/music/music.js"
  },
  {
    "revision": "62ebf8e2ee772b179bf6f60ada8a5e78",
    "url": "editor/dialogs/scrawl/scrawl.js"
  },
  {
    "revision": "766cca4f94926568567368a679fe6745",
    "url": "editor/dialogs/snapscreen/snapscreen.html"
  },
  {
    "revision": "5c7e4ef7709bcab2bad98dd69d074ce9",
    "url": "editor/dialogs/scrawl/images/eraser.png"
  },
  {
    "revision": "56deb06158f5e87f2919ecfcdc34596e",
    "url": "editor/dialogs/searchreplace/searchreplace.js"
  },
  {
    "revision": "6793ba63c50af16fb02d9c7d4969853d",
    "url": "editor/dialogs/searchreplace/searchreplace.html"
  },
  {
    "revision": "90cc2b707f28198d0594c6094dcb8d1d",
    "url": "editor/dialogs/spechars/spechars.js"
  },
  {
    "revision": "c622f9eb6ec86c015aae5200e5d3beee",
    "url": "editor/dialogs/table/dragicon.png"
  },
  {
    "revision": "81b73b33c0dedec8c0c6d58d410c3af0",
    "url": "editor/dialogs/spechars/spechars.html"
  },
  {
    "revision": "dd7096054b03244de0c56da45fc8e2f8",
    "url": "editor/dialogs/table/edittable.css"
  },
  {
    "revision": "2f9dc1669b05856a3d19907319b5ea16",
    "url": "editor/dialogs/table/edittable.html"
  },
  {
    "revision": "8e61b9c3e9c7daad97f6711804edd3c2",
    "url": "editor/dialogs/table/edittd.html"
  },
  {
    "revision": "b4610606db9110f4c59da1ac2fcb39ff",
    "url": "editor/dialogs/table/edittip.html"
  },
  {
    "revision": "9b0d87d61c649566e828ac1f4a0dd595",
    "url": "editor/dialogs/template/images/bg.gif"
  },
  {
    "revision": "e73bee7da98c7f1f8f56c24dc1f25025",
    "url": "editor/dialogs/template/images/pre1.png"
  },
  {
    "revision": "fb91f0dc61c7fe6907ff3e1474d30d0a",
    "url": "editor/dialogs/template/images/pre0.png"
  },
  {
    "revision": "dde76455a773b6f56b8fcd2548f03319",
    "url": "editor/dialogs/template/images/pre2.png"
  },
  {
    "revision": "f12f7bc32ff0b6992f57c01e9a64c6d1",
    "url": "editor/dialogs/template/images/pre3.png"
  },
  {
    "revision": "762f96c0b86af5f3f8f7bc6b0c3730dc",
    "url": "editor/dialogs/template/images/pre4.png"
  },
  {
    "revision": "3099e6fb1f29eb2516147001b5eafa8d",
    "url": "editor/dialogs/table/edittable.js"
  },
  {
    "revision": "b6e07e95f99ee3c4019647c04e50acd8",
    "url": "editor/dialogs/template/config.js"
  },
  {
    "revision": "6d1b19496d7aef646b25489c6fccc229",
    "url": "editor/dialogs/template/template.html"
  },
  {
    "revision": "2d165cce8b44acfa83dea402200d03a8",
    "url": "editor/dialogs/template/template.css"
  },
  {
    "revision": "05ca4321ceec26fadcfd9b607cbfa44f",
    "url": "editor/dialogs/template/template.js"
  },
  {
    "revision": "ceea3f7e3d18fbefe125725c85a57aeb",
    "url": "editor/dialogs/video/images/bg.png"
  },
  {
    "revision": "13813ba01bf8267721a8a9d9ea56bf90",
    "url": "editor/dialogs/video/images/center_focus.jpg"
  },
  {
    "revision": "dc9038bc535e0f930306894cf24ccd4c",
    "url": "editor/dialogs/video/images/icons.gif"
  },
  {
    "revision": "f43725a2e01286fd452243252df94999",
    "url": "editor/dialogs/video/images/file-icons.png"
  },
  {
    "revision": "324d921eed88618391328e94d34f0e2b",
    "url": "editor/lang/zh-cn/zh-cn.js"
  },
  {
    "revision": "d2c9d1cc2171bd79a1bcf6ba14f01585",
    "url": "editor/third-party/video-js/font/vjs.woff"
  },
  {
    "revision": "e6f556abcbe48e0115995bcc106a8531",
    "url": "editor/dialogs/video/images/left_focus.jpg"
  },
  {
    "revision": "85b08393f830bcc62c1376252b807f81",
    "url": "editor/dialogs/video/images/none_focus.jpg"
  },
  {
    "revision": "6b00566e6a7a54df0b83fe8a1d8b9427",
    "url": "editor/dialogs/video/images/image.png"
  },
  {
    "revision": "ed0561f6f3ee16671de9",
    "url": "assets/js/chunk-2d0ab43a.a75d8f4d.js"
  },
  {
    "revision": "56879ca275183bef11a8972ffbea5a6b",
    "url": "editor/dialogs/video/images/success.gif"
  },
  {
    "revision": "46732e763f50c337fecabcc42150d842",
    "url": "editor/dialogs/video/images/progress.png"
  },
  {
    "revision": "b80425bbf53402d499d54c86ca365870",
    "url": "editor/dialogs/video/images/success.png"
  },
  {
    "revision": "c9ceb83c0a247ae47f54c3e1d3cb4bac",
    "url": "editor/dialogs/video/images/icons.png"
  },
  {
    "revision": "07717c17dad5dddeeb3b9cd46cf178b1",
    "url": "editor/dialogs/webapp/webapp.html"
  },
  {
    "revision": "d2d913c265a619e932db9f551d1bf99d",
    "url": "editor/dialogs/video/video.html"
  },
  {
    "revision": "ee7d49d00de40b9b2e0f7179f90e7dc5",
    "url": "editor/dialogs/wordimage/fClipboard_ueditor.swf"
  },
  {
    "revision": "6081dfee26057e485cec1e879f2e0da1",
    "url": "editor/dialogs/video/video.css"
  },
  {
    "revision": "9ccc8955a6a802cfb15e29238a777122",
    "url": "editor/dialogs/wordimage/wordimage.html"
  },
  {
    "revision": "02d5d833b260cc11a116b005f05df232",
    "url": "editor/dialogs/wordimage/tangram.js"
  },
  {
    "revision": "d6f4e67cf8bce465e74d5786e7b5f209",
    "url": "editor/dialogs/video/video.js"
  },
  {
    "revision": "e9397358f963ab35bb8ad2a610395212",
    "url": "editor/dialogs/wordimage/imageUploader.swf"
  },
  {
    "revision": "7bc0d045d2d97824d012335166c9660a",
    "url": "editor/jsp/controller.jsp"
  },
  {
    "revision": "65c21036d1e7160e992a5a8e26f21b1f",
    "url": "editor/dialogs/wordimage/wordimage.js"
  },
  {
    "revision": "da5d8d5c016ae8886e20ef1ee8a324d9",
    "url": "editor/jsp/config.json"
  },
  {
    "revision": "ed8eec445e21ec7e49b86bf3cbcffcbc",
    "url": "editor/jsp/lib/commons-fileupload-1.3.1.jar"
  },
  {
    "revision": "7f97854dc04c119d461fed14f5d8bb96",
    "url": "editor/jsp/lib/commons-io-2.4.jar"
  },
  {
    "revision": "75615356605c8128013da9e3ac62a249",
    "url": "editor/jsp/lib/commons-codec-1.9.jar"
  },
  {
    "revision": "2fe7e1cc52fc2199c3efdfdd67b2ea47",
    "url": "editor/jsp/lib/ueditor-1.1.2.jar"
  },
  {
    "revision": "4a27f7cf00f964fb3f8cbcfab0c52cba",
    "url": "editor/index.html"
  },
  {
    "revision": "294b687be8ded3a31ebd2e945bab7f27",
    "url": "editor/jsp/lib/json.jar"
  },
  {
    "revision": "b97ef4ba6edca618c6dc37724b051d43",
    "url": "editor/lang/en/en.js"
  },
  {
    "revision": "6d7265b07429ceca1b03fce1e9266e14",
    "url": "editor/lang/en/images/alldeletebtnupskin.png"
  },
  {
    "revision": "d3320c66e053049d1fed97de1422006b",
    "url": "editor/lang/en/images/background.png"
  },
  {
    "revision": "dfa3aef5fe3087a5450753aa28529304",
    "url": "editor/lang/en/images/button.png"
  },
  {
    "revision": "4c5b9e9ad29724e8a1296059523d56f5",
    "url": "editor/lang/en/images/deletedisable.png"
  },
  {
    "revision": "b012453148feba7207940356f0db91e2",
    "url": "editor/lang/en/images/deleteenable.png"
  },
  {
    "revision": "b512aa9fa0ee7783ff516f9f0828b060",
    "url": "editor/lang/en/images/copy.png"
  },
  {
    "revision": "3ad9255e6398f1694395b0e0c3d330a4",
    "url": "editor/lang/en/images/listbackground.png"
  },
  {
    "revision": "88e7d05b61025278ff1b1230cfd21aa5",
    "url": "editor/lang/en/images/addimage.png"
  },
  {
    "revision": "1eb887698a395ffb7f1a6175d05442af",
    "url": "editor/lang/en/images/alldeletebtnhoverskin.png"
  },
  {
    "revision": "98b6c213a9b89b7959da7aeb7368c738",
    "url": "editor/lang/en/images/localimage.png"
  },
  {
    "revision": "6cae1397f4ae4f052293ca7a42fdf16c",
    "url": "editor/lang/en/images/rotateleftdisable.png"
  },
  {
    "revision": "34206a03b2459da6ad36ff6ad2998fa0",
    "url": "editor/lang/en/images/rotaterightdisable.png"
  },
  {
    "revision": "9e6628c34db960d682a591bc24d4f557",
    "url": "editor/lang/en/images/rotateleftenable.png"
  },
  {
    "revision": "bfc1b0155bfe9e60373c6e7f131f2771",
    "url": "editor/lang/en/images/rotaterightenable.png"
  },
  {
    "revision": "2cd78f0b4eb01b8f00a44bfb029e3824",
    "url": "editor/lang/en/images/music.png"
  },
  {
    "revision": "9da36dab96ef97bf14115b4bd5169e78",
    "url": "editor/lang/en/images/upload.png"
  },
  {
    "revision": "c754e6ca1921cd639739499d3cf45875",
    "url": "editor/lang/zh-cn/images/localimage.png"
  },
  {
    "revision": "40644255bb10f102763cbce4a3a2f7d9",
    "url": "editor/lang/zh-cn/images/copy.png"
  },
  {
    "revision": "e0a1a76441b4da770097e1af0a650b93",
    "url": "editor/lang/zh-cn/images/upload.png"
  },
  {
    "revision": "5e972a171b0d8e907563d64ec1677ee3",
    "url": "editor/themes/default/dialogbase.css"
  },
  {
    "revision": "60a2121d55f9238f529458ee5f2e6e4e",
    "url": "editor/themes/default/images/anchor.gif"
  },
  {
    "revision": "51ba4f6856cb8df8acf979cc73cab7bb",
    "url": "editor/themes/default/css/ueditor.min.css"
  },
  {
    "revision": "af3d19c5d7f4e5998f94cffff14cd297",
    "url": "editor/themes/default/css/ueditor.css"
  },
  {
    "revision": "6d299069db6f24cf2ba1a90a64b49db7",
    "url": "editor/lang/zh-cn/images/music.png"
  },
  {
    "revision": "06a16826b506f5264e29cc3c84137455",
    "url": "editor/themes/default/images/arrow_down.png"
  },
  {
    "revision": "1c5b6a4191ae6122048d44e9a40d8974",
    "url": "editor/themes/default/images/arrow.png"
  },
  {
    "revision": "888bff7ff3165632455621e1b899287d",
    "url": "editor/themes/default/images/arrow_up.png"
  },
  {
    "revision": "6555bb1e761aba45078f600eee974a66",
    "url": "editor/themes/default/images/charts.png"
  },
  {
    "revision": "d25ebcb51beae52a5a3f8c658d1c00d9",
    "url": "editor/themes/default/images/cursor_h.png"
  },
  {
    "revision": "0950cf5272ea8e30635e1c27954bf104",
    "url": "editor/themes/default/images/cursor_h.gif"
  },
  {
    "revision": "fe9d01cb9e8b0cc9a34ed668f8acfb6a",
    "url": "editor/themes/default/images/cursor_v.gif"
  },
  {
    "revision": "270f36fdf73544c528fe81d5494d5c6f",
    "url": "editor/themes/default/images/cursor_v.png"
  },
  {
    "revision": "087d3bd9f0f43aee0adb3f39a6e5ba17",
    "url": "editor/themes/default/images/button-bg.gif"
  },
  {
    "revision": "940250e1b9b228f11916e9591417235e",
    "url": "editor/themes/default/images/highlighted.gif"
  },
  {
    "revision": "f8bcaa64071e4173b7cd8daa9613ff34",
    "url": "editor/themes/default/images/cancelbutton.gif"
  },
  {
    "revision": "1c4486a78ac7758a7ab3bd84e1a38066",
    "url": "editor/themes/default/images/dialog-title-bg.png"
  },
  {
    "revision": "885afa097b98821279ea8aa3c68cc293",
    "url": "editor/themes/default/images/icons-all.gif"
  },
  {
    "revision": "b5b96bbb19c82b712538d9eba562873a",
    "url": "editor/themes/default/images/filescan.png"
  },
  {
    "revision": "8dc0567ff9656e738b562e50db1e5b86",
    "url": "editor/themes/default/images/loaderror.png"
  },
  {
    "revision": "9c92dd524f2abd5edc87d2d46d4a10de",
    "url": "editor/themes/default/images/loading.gif"
  },
  {
    "revision": "59caae8ab95b2eeba9444ba219446c75",
    "url": "editor/themes/default/images/pagebreak.gif"
  },
  {
    "revision": "4869b022d6ba52d8c4312e9f40564efd",
    "url": "editor/themes/default/images/neweditor-tab-bg.png"
  },
  {
    "revision": "44274c1e95b775c004f110f84db1c058",
    "url": "editor/themes/default/images/scale.png"
  },
  {
    "revision": "df3e567d6f16d040326c7a0ea29a4f41",
    "url": "editor/themes/default/images/spacer.gif"
  },
  {
    "revision": "b2939e1b402cc732c078ec8fd3b10974",
    "url": "editor/themes/default/images/lock.gif"
  },
  {
    "revision": "297a921544f1f9518b1180bb74317c9a",
    "url": "editor/themes/default/images/sortable.png"
  },
  {
    "revision": "9d34b0cc46ae6d88e3c7183933be762f",
    "url": "editor/themes/default/images/sparator_v.png"
  },
  {
    "revision": "968d0b018b12153f0f0f2a736273ef5e",
    "url": "editor/third-party/video-js/video-js.swf"
  },
  {
    "revision": "6ffe01bf317ac098a88868d5036cc5f8",
    "url": "editor/themes/default/images/icons.png"
  },
  {
    "revision": "ccba56505949f6d112ff6127d9b7eef0",
    "url": "editor/themes/default/images/unhighlighted.gif"
  },
  {
    "revision": "d6ed19f7eb5d55fc824c588465cf2647",
    "url": "editor/themes/default/images/icons.gif"
  },
  {
    "revision": "fc2b48359037a6f185634fbe31fcb1ae",
    "url": "editor/themes/default/images/toolbar_bg.png"
  },
  {
    "revision": "c58df79dc817794353a65858035b71b6",
    "url": "editor/themes/default/images/tangram-colorpicker.png"
  },
  {
    "revision": "676456b57740b2a325b23a54902d21a6",
    "url": "editor/themes/default/images/table-cell-align.png"
  },
  {
    "revision": "e0a1a76441b4da770097e1af0a650b93",
    "url": "editor/themes/default/images/upload.png"
  },
  {
    "revision": "c78d50851eeb7922d57ef3281f676dd1",
    "url": "editor/themes/default/images/wordpaste.png"
  },
  {
    "revision": "04bcb769fd963876e783253637007fe2",
    "url": "editor/themes/iframe.css"
  },
  {
    "revision": "f857581368e75fcada43649be5de483b",
    "url": "editor/themes/default/images/videologo.gif"
  },
  {
    "revision": "0bc553bf91fd21796d9444b4b444f899",
    "url": "editor/themes/default/images/word.gif"
  },
  {
    "revision": "2ab8b08e3d99c1e61c9b56601848412e",
    "url": "editor/third-party/codemirror/codemirror.css"
  },
  {
    "revision": "2fa6f41918cfdbb2b53cda9b3ce7cd49",
    "url": "editor/third-party/SyntaxHighlighter/shCoreDefault.css"
  },
  {
    "revision": "c555d2393faeda77191724178c6cfaaa",
    "url": "editor/third-party/highcharts/adapters/mootools-adapter.src.js"
  },
  {
    "revision": "b740069c9dfb747f06449d05f398d96e",
    "url": "editor/third-party/highcharts/adapters/prototype-adapter.js"
  },
  {
    "revision": "caadadf17ad7a5372a9cdfa6a1d61d58",
    "url": "editor/third-party/codemirror/codemirror.js"
  },
  {
    "revision": "c96a6c07c23483a59f247c64192c8cc6",
    "url": "editor/third-party/highcharts/adapters/mootools-adapter.js"
  },
  {
    "revision": "566f0854479ba660c70602344876f80d",
    "url": "editor/third-party/highcharts/adapters/prototype-adapter.src.js"
  },
  {
    "revision": "28edf9ce1a85c74da85177298cc4d681",
    "url": "editor/third-party/highcharts/highcharts-more.js"
  },
  {
    "revision": "a135ee3d19ac2e43b4919cc08df09597",
    "url": "editor/third-party/highcharts/highcharts-more.src.js"
  },
  {
    "revision": "c65b1fa5cddda5691b788d0f57cf15a1",
    "url": "editor/third-party/highcharts/adapters/standalone-framework.src.js"
  },
  {
    "revision": "618e64fd24de4603efd34c884be3b381",
    "url": "editor/third-party/highcharts/highcharts.js"
  },
  {
    "revision": "68ec1cd67c9092535bef258a7021f0b2",
    "url": "editor/third-party/highcharts/adapters/standalone-framework.js"
  },
  {
    "revision": "05fc417638d360f18279cc6fdd24b96d",
    "url": "editor/third-party/highcharts/modules/annotations.src.js"
  },
  {
    "revision": "4afb96b809f40e01e6a0bd65baa8fd35",
    "url": "editor/third-party/highcharts/modules/annotations.js"
  },
  {
    "revision": "5a665f0e03eeda8a491fcb5005e6f369",
    "url": "editor/third-party/highcharts/highcharts.src.js"
  },
  {
    "revision": "2b6cc59ea7332fa69a28b5045c8bb4ee",
    "url": "editor/third-party/highcharts/modules/canvas-tools.src.js"
  },
  {
    "revision": "5aec4f24d98e30b10f702226108be657",
    "url": "editor/third-party/highcharts/modules/data.src.js"
  },
  {
    "revision": "44c97a99d743557f2a62cd491ad67868",
    "url": "editor/third-party/highcharts/modules/canvas-tools.js"
  },
  {
    "revision": "cbdf1eed29dde8296e4a6978e3435273",
    "url": "editor/third-party/highcharts/modules/drilldown.src.js"
  },
  {
    "revision": "510e480f268aa36e3cf1900d0abb99de",
    "url": "editor/third-party/highcharts/modules/exporting.js"
  },
  {
    "revision": "d3f180987716c39ac6e5c550f67c4c81",
    "url": "editor/third-party/highcharts/modules/data.js"
  },
  {
    "revision": "6f7c0fab1b4928cc72845994f710eaf6",
    "url": "editor/third-party/highcharts/modules/drilldown.js"
  },
  {
    "revision": "39e9f9057497402dde01f47c41ca3bcc",
    "url": "editor/third-party/highcharts/modules/heatmap.js"
  },
  {
    "revision": "bfdde27ffd6e557f95c7484f80400ebf",
    "url": "editor/third-party/highcharts/modules/funnel.src.js"
  },
  {
    "revision": "9327ba44f8cdc1edcf83e397e889cb08",
    "url": "editor/third-party/highcharts/modules/funnel.js"
  },
  {
    "revision": "719ac2b68ef253125c095cd502de756d",
    "url": "editor/third-party/highcharts/modules/heatmap.src.js"
  },
  {
    "revision": "8dc9ec41cf2747515f8b4c689387a864",
    "url": "editor/third-party/highcharts/modules/map.js"
  },
  {
    "revision": "17e1b0d3950fdffda42694c19d2077b3",
    "url": "editor/third-party/highcharts/modules/no-data-to-display.js"
  },
  {
    "revision": "f3372ce263f7f21253a4f3648d7c3cc3",
    "url": "editor/third-party/highcharts/modules/no-data-to-display.src.js"
  },
  {
    "revision": "598d05af8b1440bed467a8a1f14909e7",
    "url": "editor/third-party/highcharts/themes/dark-blue.js"
  },
  {
    "revision": "751ade611cfbb4785f21511d32ab7891",
    "url": "editor/third-party/highcharts/themes/dark-green.js"
  },
  {
    "revision": "843c137978954b072fb8ff2097f5f05d",
    "url": "editor/third-party/highcharts/themes/grid.js"
  },
  {
    "revision": "24f5a2a8e34b2273295f7295d48163be",
    "url": "editor/third-party/highcharts/themes/gray.js"
  },
  {
    "revision": "edeff203b4d4d56d7f1eaf9c2d8e8b76",
    "url": "editor/third-party/highcharts/themes/skies.js"
  },
  {
    "revision": "e3a16272b55bf29fe0ce67f7b9dae4ce",
    "url": "editor/third-party/highcharts/modules/exporting.src.js"
  },
  {
    "revision": "534facf0901e5fbc5a06c27e75969c92",
    "url": "editor/third-party/highcharts/modules/map.src.js"
  },
  {
    "revision": "e4d2dd20f706c7cbde2184f38b1de09f",
    "url": "editor/third-party/snapscreen/UEditorSnapscreen.exe"
  },
  {
    "revision": "91515770ce8c55de23b306444d8ea998",
    "url": "editor/third-party/jquery-1.10.2.js"
  },
  {
    "revision": "f9c63739c4e5163ab00e257bd4e8a461",
    "url": "editor/third-party/video-js/font/vjs.eot"
  },
  {
    "revision": "628072e7212db1e8cdacb22b21752cda",
    "url": "editor/third-party/jquery-1.10.2.min.js"
  },
  {
    "revision": "0eb58bb31b855635ebd80e65d797e2c2",
    "url": "editor/third-party/video-js/font/vjs.svg"
  },
  {
    "revision": "b4f775128900e33fd2a7c12b46b41b96",
    "url": "editor/third-party/SyntaxHighlighter/shCore.js"
  },
  {
    "revision": "600c44c3d87f2893277dd93bf02b3e50",
    "url": "editor/third-party/video-js/font/vjs.ttf"
  },
  {
    "revision": "4b6813504d31e3b11655aafacf165db4",
    "url": "editor/third-party/video-js/video-js.min.css"
  },
  {
    "revision": "b878daf5c0a46c98ba28740a072585f4",
    "url": "assets/img/footer-bg.b878daf5.png"
  },
  {
    "revision": "822ae73f6b0b05e9361e",
    "url": "assets/css/chunk-1a73fbc6.a3f3bc55.css"
  },
  {
    "revision": "e884146d0c53836fa536",
    "url": "assets/js/app.7c2a2858.js"
  },
  {
    "revision": "64ce67cb62cc89f4fa70",
    "url": "assets/css/chunk-1e5be3a0.84c378bc.css"
  },
  {
    "revision": "c007e80e0a63462da7340d781e45a647",
    "url": "assets/img/iconfont.c007e80e.svg"
  },
  {
    "revision": "00a520a30ed7b6cc61905c4d4ca57177",
    "url": "assets/fonts/iconfont.00a520a3.ttf"
  },
  {
    "revision": "032f46065e2e50918c2329d31d9a785a",
    "url": "assets/fonts/iconfont.032f4606.woff"
  },
  {
    "revision": "002ab83f1d70933429feea75526b5a52",
    "url": "assets/fonts/iconfont.002ab83f.eot"
  },
  {
    "revision": "8d7d8cb0d2a0a9cc8b10faab1d68cdd3",
    "url": "assets/img/qrcode.8d7d8cb0.png"
  },
  {
    "revision": "c8655c0b1ef540b20ec7d14e17dae3b2",
    "url": "assets/img/logo.c8655c0b.png"
  },
  {
    "revision": "7798aa63f5d39111c2c9fb7a2fac6ee3",
    "url": "assets/img/icon-sprite-sign.7798aa63.png"
  },
  {
    "revision": "58b592441cd7d2ff8b7dccb207f73cab",
    "url": "assets/img/bg.58b59244.png"
  },
  {
    "revision": "d8bfaf936bca10aa121cb996c9120dbd",
    "url": "assets/img/block-bg.d8bfaf93.png"
  },
  {
    "revision": "822ae73f6b0b05e9361e",
    "url": "assets/js/chunk-1a73fbc6.7dd8c01f.js"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "assets/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "assets/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "8b24ebfe7ac01cb30946dfbdc699d611",
    "url": "assets/img/head_img.8b24ebfe.png"
  },
  {
    "revision": "54afb1a43f1fad9b6d44",
    "url": "assets/css/chunk-vendors.bcaf7fb4.css"
  },
  {
    "revision": "0d60c84ad452d3c0fe02",
    "url": "assets/css/chunk-b2e0cb02.effc5dcc.css"
  },
  {
    "revision": "f20d0941387f7e771cde",
    "url": "assets/css/chunk-881417c4.5590ac6e.css"
  },
  {
    "revision": "cc5922d3d0fad70d7995",
    "url": "assets/js/chunk-0a6d973a.b2f01fdf.js"
  },
  {
    "revision": "9e596ec1045f15e57853",
    "url": "assets/js/chunk-0358353a.f331119d.js"
  },
  {
    "revision": "841660f6648f9d2496a2",
    "url": "assets/css/chunk-382e845f.11ca6122.css"
  },
  {
    "revision": "cc5922d3d0fad70d7995",
    "url": "assets/css/chunk-0a6d973a.d276e8ec.css"
  },
  {
    "revision": "9e596ec1045f15e57853",
    "url": "assets/css/chunk-0358353a.1d340587.css"
  },
  {
    "revision": "e884146d0c53836fa536",
    "url": "assets/css/app.8c379079.css"
  }
];